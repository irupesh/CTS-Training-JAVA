

public class Match {
private String teamA;
private String teamB;
private String teamAscore;
private String teamBscore;
public Match()
{
	
}
public Match(String teamA,String teamB,String teamAscore,String teamBscore)
{
	this.teamA=teamA;
	this.teamB=teamB;
	this.teamAscore=teamAscore;
	this.teamBscore=teamBscore;
	
}
public String getTeamA() {
	return teamA;
}
public void setTeamA(String teamA) {
	this.teamA = teamA;
}
public String getTeamB() {
	return teamB;
}
public void setTeamB(String teamB) {
	this.teamB = teamB;
}
public String getTeamAscore() {
	return teamAscore;
}
public void setTeamAscore(String teamAscore) {
	this.teamAscore = teamAscore;
}
public String getTeamBscore() {
	return teamBscore;
}
public void setTeamBscore(String teamBscore) {
	this.teamBscore = teamBscore;
}

//fill the code

}
