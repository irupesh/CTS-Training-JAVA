
public interface IKabbadiPlayerStatistics {
	public void displayKabbadiPlayerDetails();
}
