import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		ArrayList<SortScore> scores = new ArrayList<SortScore>();
		Scanner input = new Scanner(System.in);
		
		for(int i=0;i<3;i++){
			System.out.println("Enter the Match :");
			String match = input.nextLine();
			System.out.println("Enter the Scores :");
			String scoreString = input.nextLine();
			SortScore obj = new SortScore(match, scoreString);
			scores.add(obj);
		}
		
		for(SortScore score:scores){
			score.start();
			score.join();
		}
		
		System.out.println("Ordered Score List");
		for(SortScore score:scores){
			System.out.println("Match : "+score.matchType);
			Integer[] sc = score.getScores();
			for(Integer i : sc){
				System.out.println(i);
			}
			
		}
		input.close();
	}

}
