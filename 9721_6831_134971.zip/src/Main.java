import java.io.Serializable;

class Main implements Serializable{
	
}