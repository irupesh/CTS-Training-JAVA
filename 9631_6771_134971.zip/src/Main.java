import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
		public static void main(String[] args) {
			
			Scanner input = new Scanner(System.in);
			HashMap<String, Integer > map1 = new HashMap<String, Integer>();
			HashMap<String, Integer > map2 = new HashMap<String, Integer>();
			int number = input.nextInt();
			
			for(int i=0;i<number;i++){
				input.nextLine();
				String id = input.nextLine();
				int theoryMarks = input.nextInt();
				int labMarks = input.nextInt();
				map1.put(id, theoryMarks);
				map2.put(id, labMarks);
				
			}
			input.close();
			
			TreeMap<String, Character > result = UserMainCode.calculateGrades(map1, map2);
			
			for(Map.Entry<String, Character> entry:result.entrySet())  
				System.out.println(entry.getKey()+"\n"+entry.getValue());
	}

}
