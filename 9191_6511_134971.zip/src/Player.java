
public class Player {
	protected String name;
	protected String teamName;
	protected long noOfMatches;
	public Player(String name, String teamName, Long noOfMatches) {
		super();
		this.name = name;
		this.teamName = teamName;
		this.noOfMatches = noOfMatches;
	}
	void displayDetails(){
		
	}
	

}
