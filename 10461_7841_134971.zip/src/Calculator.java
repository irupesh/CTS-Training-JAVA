
public class Calculator {
	
	@Arithmetic
	public void addition(){}
	
	@Arithmetic
	public void subtraction(){}
	
	@Arithmetic
	public void multiplication(){}
	
	@Arithmetic
	public void division(){}
	
	@Scientific
	public void sine(){}
	
	@Scientific
	public void cosine(){}
	
	@Scientific
	public void tangent(){}
	
	@Scientific
	public void logarithm(){}

}
